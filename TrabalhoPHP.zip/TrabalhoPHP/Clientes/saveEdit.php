<?php
    // isset -> serve para saber se uma variável está definida
    include_once('config.php');
    if(isset($_POST['update']))
    {      // O que ta no banco recebe as variaveis
        $idCliente = $_POST['id'];
        $ClienteNome = $_POST['nome'];
        $ClienteCpf = $_POST['cpf'];
        $ClienteTelefone = $_POST['telefone'];
        $ClienteEmail = $_POST['email'];

        $ClienteRua = $_POST['rua'];
        $ClienteNumero = $_POST['numero'];
        $ClienteBairro = $_POST['bairro'];
        $ClienteCidade = $_POST['cidade'];
        //$data_nasc = $_POST['data_nascimento'];
       
        $sqlUpdate = "UPDATE Clientes
        SET ClienteNome='$ClienteNome',ClienteCpf='$ClienteCpf',ClienteTelefone='$ClienteTelefone',ClienteEmail='$ClienteEmail',ClienteRua='$ClienteRua',ClienteNumero='$ClienteNumero',ClienteBairro='$ClienteBairro',ClienteCidade='$ClienteCidade'
        WHERE idCliente=$idCliente";
        $result = $conexao->query($sqlUpdate);
        print_r($result);
    }
    header('Location: pesquisarClientes.php');
?>