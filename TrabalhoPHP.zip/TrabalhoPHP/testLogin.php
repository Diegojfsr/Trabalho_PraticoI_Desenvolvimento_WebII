<?php
    session_start();
    // print_r($_REQUEST);
    if(isset($_POST['submit']) && !empty($_POST['email']) && !empty($_POST['senha']))
    {
        // Acessa
        include_once('config.php');
        $Email = $_POST['email']; //variavel Email recebe o post email
        $Senha = $_POST['senha']; //variavel Senha recebe o post senha

         //print_r('Email: ' . $email);
         //print_r('<br>');
         //print_r('Senha: ' . $senha);

         // Verifica o campo UsuarioEmail e o campo UsuarioSenha da tabela e compara com as variaveis $Email e $Senha do include_once
        $sql = "SELECT * FROM Usuarios WHERE UsuarioEmail = '$Email' and UsuarioSenha = '$Senha'";  

        $result = $conexao->query($sql); //Variavel criada dentro do arquivo config.php

        //print_r($sql);
        //print_r($result);

        if(mysqli_num_rows($result) < 1)
        {
            //print_r('Não Existe');

            unset($_SESSION['email']); //Destroi a section email e senha caso nao tenha a variavel
            unset($_SESSION['senha']);
            header('Location: login.php');
        }
        else
        {
            //print_r('Existe');

            $_SESSION['email'] = $Email; // cria a section com o email e com a senha
            $_SESSION['senha'] = $Senha;
            header('Location: login.php');
        }
    }
    else
    {
        // Não acessa
        header('Location: login.php');
    }
?>