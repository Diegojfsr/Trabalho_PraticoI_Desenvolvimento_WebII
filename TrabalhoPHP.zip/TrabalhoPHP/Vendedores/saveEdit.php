<?php
    // isset -> serve para saber se uma variável está definida
    include_once('config.php');
    if(isset($_POST['update']))
    {
        $idVendedor = $_POST['id'];
        $VendedorNome = $_POST['nome'];
        $VendedorTelefone = $_POST['telefone'];
        $VendedorEmail = $_POST['email'];
        
        $sqlUpdate = "UPDATE Vendedores
        SET VendedorNome='$VendedorNome',VendedorTelefone='$VendedorTelefone',VendedorEmail='$VendedorEmail'
        WHERE idVendedor=$idVendedor";
        $result = $conexao->query($sqlUpdate);
        print_r($result);
    }
    header('Location: pesquisarVendedores.php');

?>