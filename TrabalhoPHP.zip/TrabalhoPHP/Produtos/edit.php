<?php
    if(!empty($_GET['id']))
    {
        include_once('config.php');

        $id = $_GET['id'];
        $sqlSelect = "SELECT * FROM produtos WHERE idProduto=$id";
        $result = $conexao->query($sqlSelect);
        //print_r($result);
        if($result->num_rows > 0)
        {
            while($user_data = mysqli_fetch_assoc($result))
            {
                $nome = $user_data['ProdutoNome'];//variavel nome recebe o valor Produto nome que ta no BD
                $preco = $user_data['ProdutoPreco'];
                $descricao = $user_data['ProdutoDescricao'];
                $imagem = $user_data['ProdutoImagem'];


                //$ClienteNome = $user_data['nome'];
                //$ClienteCpf = $user_data['cpf'];
                //$ClienteTelefone = $user_data['telefone'];
                //$ClienteEmail = $user_data['email'];
        
                //$ClienteRua = $user_data['rua'];
                //$ClienteNumero	 = $user_data['numero'];
                //$ClienteBairro = $user_data['bairro'];
                //$ClienteCidade = $user_data['cidade'];
            }
            //print_r($nome);
        }
        else
        {
            header('Location: pesquisarprodutos.php');
        }
    }
    //else
    //{
        //header('Location: sistema.php');
    //}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Formulário Produtos</title>
    <style>
        body{
            background: linear-gradient(to right, rgb(20, 147, 220), rgb(17, 54, 71));
            color: white;
            text-align: center;
        }
        .table-bg{
            background: rgba(0, 0, 0, 0.3);
            border-radius: 15px 15px 0 0;
        }

        .box-search{
            display: flex;
            justify-content: center;
            gap: .1%;
        }
    </style>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
        <h5> SISTEMA PHP </h5>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
        <div class="d-flex">
            <a href="pesquisarProdutos.php" class="btn btn-danger me-5">Voltar</a>
            <!-- <a href="sair.php" class="btn btn-danger me-5">Sair</a> -->
        </div>
    </nav>
    <br>

    <div class="box">
    <form action="formularioProdutos.php" method="POST">
            <fieldset>
                <legend><b>Fórmulário de Produtos</b></legend>
                <br>
                <div class="inputBox">
                    <input type="text" name="nome" id="nome" class="inputUser" value=<?php echo $nome;?> required>
                    <label for="nome" class="labelInput">Nome Produto</label>
                </div>
                <br>
                <div class="inputBox">
                    <input type="text" name="preco" id="preco" class="inputUser" value=<?php echo $preco;?> required>
                    <label for="preco" class="labelInput">Preco</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="descricao" id="descricao" class="inputUser" value=<?php echo $descricao;?> required>
                    <label for="descricao" class="labelInput">Descricao</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="imagem" name="imagem" id="imagem" class="inputUser" value=<?php echo $imagem;?> required>
                    <label for="imagem" class="labelInput">Imagem</label>
                </div>
                
                <br><br>
                <input type="submit" name="submit" id="submit">
            </fieldset>
        </form>
    </div>
</body>
</html>