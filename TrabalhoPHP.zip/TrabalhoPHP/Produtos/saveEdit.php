<?php
    // isset -> serve para saber se uma variável está definida
    include_once('config.php');
    if(isset($_POST['update']))
    {      // O que ta no banco recebe as variaveis
        $idProduto = $_POST['id'];
        $ProdutoNome = $_POST['nome'];
        $ProdutoPreco = $_POST['preco'];
        $ProdutoDescricao = $_POST['descricao'];
        $ProdutoImagem = $_POST['imagem'];
       
        $sqlUpdate = "UPDATE Produtos
        SET ProdutoNome='$ProdutoNome',ProdutoPreco='$ProdutoPreco',ProdutoDescricao='$ProdutoDescricao',ProdutoImagem='$ProdutoImagem'
        WHERE idProduto=$idProduto";
        $result = $conexao->query($sqlUpdate);
        print_r($result);
    }
    header('Location: pesquisarProdutos.php');
?>