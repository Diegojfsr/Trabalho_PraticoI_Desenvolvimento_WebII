<?php
    if(isset($_POST['submit']))
    {
        include_once('config.php'); // Puxa o arquivo config.php onde contem os dados da conexao com o banco

        $ProdutoNome = $_POST['nome'];
        $ProdutoPreco = $_POST['preco'];
        $ProdutoDescricao = $_POST['descricao'];
        $ProdutoImagem = $_POST['imagem'];



        $result = mysqli_query($conexao, "INSERT INTO produtos(ProdutoNome,ProdutoPreco,ProdutoDescricao,ProdutoImagem) 
        VALUES ('$ProdutoNome','$ProdutoPreco','$ProdutoDescricao','$ProdutoImagem')");

        header('Location: formularioProdutos.php');
    }  
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>SISTEMA PHP</title>
    <style>
        body{
            background: linear-gradient(to right, rgb(20, 147, 220), rgb(17, 54, 71));
            color: white;
            text-align: center;
        }
        .table-bg{
            background: rgba(0, 0, 0, 0.3);
            border-radius: 15px 15px 0 0;
        }

        .box-search{
            display: flex;
            justify-content: center;
            gap: .1%;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <div class="d-flex">
                <a href="pesquisarProdutos.php" class="btn btn-danger me-5">Voltar</a>
            </div>
        </div>
    </nav>

    <div class="box">
        <form action="formularioProdutos.php" method="POST">
            <fieldset>
                <legend><b>Fórmulário de Produtos</b></legend>
                <br>
                <div class="inputBox">
                    <input type="text" name="nome" id="nome" class="inputUser" required>
                    <label for="nome" class="labelInput">Nome Produto</label>
                </div>
                <br>
                <div class="inputBox">
                    <input type="text" name="preco" id="preco" class="inputUser" required>
                    <label for="preco" class="labelInput">Preco</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="descricao" id="descricao" class="inputUser" required>
                    <label for="descricao" class="labelInput">Descricao</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="imagem" id="imagem" class="inputUser" required>
                    <label for="imagem" class="labelInput">Imagem</label>
                </div>
                
                <br><br>
                <input type="submit" name="submit" id="submit">
            </fieldset>
        </form>
    </div>
</body>
</html>

