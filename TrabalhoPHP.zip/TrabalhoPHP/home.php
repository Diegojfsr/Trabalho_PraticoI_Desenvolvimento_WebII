<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <title>SISTEMA PHP</title>

        <style>
            body{
                background: linear-gradient(to right, rgb(20, 147, 220), rgb(17, 54, 71));
                color: white;
                text-align: center;
            }
            .table-bg{
                background: rgba(0, 0, 0, 0.3);
                border-radius: 15px 15px 0 0;
            }

            .box{
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%,-50%);
                background-color: rgba(0, 0, 0, 0.6);
                padding: 30px;
                border-radius: 10px;
            }
            a{
                text-decoration: none;
                color: white;
                border: 3px solid dodgerblue;
                border-radius: 10px;
                padding: 10px;
            }
            a:hover{
                background-color: dodgerblue;
            }

            .table-bg{
                background: rgba(0, 0, 0, 0.3);
                border-radius: 15px 15px 0 0;
            }

            .box-search{
                display: flex;
                justify-content: center;
                gap: .1%;
            }
            
        </style>
    </head>

        <body>
            <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
                <div class="container-fluid">
                    <h5> SISTEMA PHP </h5>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </div>
                <div class="d-flex">
                <a href="sair.php" class="btn btn-danger me-5">Sair</a> <!--Puxa o arquivo Sair-->
                </div>
            </nav>

            <!--<h1>Projeto desenvolvido por Diego Jefferson, para fins academicos!</h1>
            <h2>Desenvolvimento WebII</h2>-->
            <div class="box">
                <!--<a href="login.php">Login</a>
                <a href="formulario.php">Cadastre-se</a>-->
                <a href="Clientes/pesquisarClientes.php">Clientes</a>
                <a href="Produtos/pesquisarProdutos.php">Produtos</a>
                <a href="pesquisarVendedores.php">Vendedores</a>
                <a href="pesquisarPedidos.php">Pedidos</a>
                <a href="pesquisarUser.php">Usuarios</a>
            </div>
        </body>
</html>