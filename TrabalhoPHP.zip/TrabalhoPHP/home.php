<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="CSS/homeStyle.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        
        <title>SISTEMA PHP</title>
        <style>
        </style>
    </head>

    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container-fluid">
                <h5> SISTEMA PHP </h5>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="d-flex">
            <a href="sair.php" class="btn btn-danger me-5">Sair</a> <!--Puxa o arquivo Sair-->
            </div>
        </nav>

        <div class="main-container">
            <div class="cards">
                <div class="card card-1">
                    <div class="card__icon"><i class="fas fa-bolt"></i></div>
                    <p class="card__exit"><i class="fas fa-times"></i></p>
                    <h2 class="card__title"> </h2>
                        <h2 class="card__apply">
                            <a class="card__link" href="Clientes/pesquisarClientes.php"> Clientes <i class="fas fa-arrow-right"></i></a>
                        </h2>
                </div>
                <div class="card card-2">
                    <div class="card__icon"><i class="fas fa-bolt"></i></div>
                    <p class="card__exit"><i class="fas fa-times"></i></p>
                    <h2 class="card__title"> </h2>
                        <h2 class="card__apply">
                            <a class="card__link" href="Produtos/pesquisarProdutos.php"> Produtos <i class="fas fa-arrow-right"></i></a>
                    </h2>
                </div>
                <div class="card card-3">
                    <div class="card__icon"><i class="fas fa-bolt"></i></div>
                    <p class="card__exit"><i class="fas fa-times"></i></p>
                    <h2 class="card__title"> </h2>
                    <h2 class="card__apply">
                        <a class="card__link" href="Vendedores/pesquisarVendedores.php"> Vendedores <i class="fas fa-arrow-right"></i></a>
                    </h2>
                </div>
                <div class="card card-4">
                    <div class="card__icon"><i class="fas fa-bolt"></i></div>
                    <p class="card__exit"><i class="fas fa-times"></i></p>
                    <h2 class="card__title"> </h2>
                    <h2 class="card__apply">
                        <a class="card__link" href="Pedidos/pesquisarPedidos.php"> Pedidos <i class="fas fa-arrow-right"></i></a>
                    </h2>
                </div>
            </div>
        </div>   
    </body>
</html>