<?php
    // isset -> serve para saber se uma variável está definida
    include_once('config.php');
    if(isset($_POST['update']))
    {      // O que ta no banco recebe as variaveis
        $idPedido = $_POST['id'];
        $VendedorNome = $_POST['nomeV'];
        $ClienteNome = $_POST['nomeC'];
        $PedidoData = $_POST['data'];
        $PedidoFrete = $_POST['frete'];
        $PedidoPrecoTotal = $_POST['precoT'];
        $PedidoPrecoTotalProduto = $_POST['precoTP'];

       
        $sqlUpdate = "UPDATE Pedidos
        SET VendedorNome='$VendedorNome',ClienteNome='$ClienteNome',PedidoData='$PedidoData',PedidoFrete='$PedidoFrete',PedidoPrecoTotal='$PedidoPrecoTotal',PedidoPrecoTotalProduto ='$PedidoPrecoTotalProduto '
        WHERE idPedido=$id";
        $result = $conexao->query($sqlUpdate);
        print_r($result);
    }
    header('Location: pesquisarPedidos.php');
?>